# TerminateWindowsUpdateCleanupConfig PowerShell 2025-06-25
# Terminate Windows Update Service!
$command = 'net stop wuauserv'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'net stop bits'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
# Clear the downloaded update file!
$command = 'del /f /s /q %windir%\SoftwareDistribution\Download\*'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
# Start Windows Update Service!
$command = 'net start wuauserv'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'net start bits'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
CLS