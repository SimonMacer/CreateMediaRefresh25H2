# DisableHVCIMemoryIntegrityVBSSettings PowerShell 2025-07-11
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass -Force
Read-Host "(HVCI) ����(���s�ҥ�) VBS �����ƫ��w���ʩM�O���駹��� > ���N���~��!"
$VBSEnableMode = Read-Host "�п�� VBS �����ƫ��w���ʩM�O���駹��ʳ]�w�Ҧ�: (D = ����;U = ���� + ���] Windows Hello �M�ϥΪ̱b��K�X;E = ���s�ҥ�)" -WarningAction Inquire
if ( $VBSEnableMode -eq 'e' )
{
$DeviceGuardKey = "HKLM:\SYSTEM\ControlSet001\Control\DeviceGuard"
try
{
Set-ItemProperty -Path $DeviceGuardKey -Name 'EnableVirtualizationBasedSecurity' -Type DWord -Value 1 -Force
} catch {}
try
{
Remove-ItemProperty -Path $DeviceGuardKey -Name 'RequirePlatformSecurityFeatures' -Force
} catch {}
$HypervisorEnforcedCodeIntegrityKey = "HKLM:\SYSTEM\ControlSet001\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity"
try
{
Set-ItemProperty -Path $HypervisorEnforcedCodeIntegrityKey -Name 'Enabled' -Type DWord -Value 1 -Force
} catch {}
CLS
$command = 'mountvol X: /s'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'copy %WINDIR%\System32\SecConfig.efi X:\EFI\Microsoft\Boot\SecConfig.efi /Y'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /create {0cb3b571-2f2e-4343-a879-d86a476d7215} /d "DebugTool" /application osloader'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /set {0cb3b571-2f2e-4343-a879-d86a476d7215} path "\EFI\Microsoft\Boot\SecConfig.efi"'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /set {bootmgr} bootsequence {0cb3b571-2f2e-4343-a879-d86a476d7215}'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /set {0cb3b571-2f2e-4343-a879-d86a476d7215} loadoptions ENABLE-LSA-ISO, ENABLE-VBS'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /set {0cb3b571-2f2e-4343-a879-d86a476d7215} device partition=X:'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'mountvol X: /d'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
CLS
Write-Output '�Э��s�Ұʨt��!'
$RebootASK = Read-Host "�z�n�ߧY���s�Ұʨt�ζ�? (Y = Yes)" -WarningAction Inquire
if ( $RebootASK -eq 'y' )
{
Restart-Computer -Force
} else {
Exit
}
}
if ( $VBSEnableMode -eq 'd' -or $VBSEnableMode -eq 'u' )
{
if ( $VBSEnableMode -eq 'u' )
{
CLS
Write-Output "���] Windows Hello �M�ϥΪ̱b��K�X��!"
Set-LocalUser -name $env:username -Password ([securestring]::new())
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name 'AllowDomainPINLogon' -Type DWord -Value 0 -Force
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\Settings\AllowSignInOptions" -Name 'value' -Type DWord -Value 0 -Force
New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Biometrics"
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Biometrics" -Name 'Enabled' -Type DWord -Value 0 -Force
New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\PassportforWork"
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\PassportforWork" -Name 'Enabled' -Type DWord -Value 0 -Force
Start-Process cmd -ArgumentList '/s,/c,takeown /f C:\Windows\ServiceProfiles\LocalService\AppData\Local\Microsoft\NGC /r /d y & icacls C:\Windows\ServiceProfiles\LocalService\AppData\Local\Microsoft\NGC /grant administrators:F /t & RD /S /Q C:\Windows\ServiceProfiles\LocalService\AppData\Local\Microsoft\Ngc & MD C:\Windows\ServiceProfiles\LocalService\AppData\Local\Microsoft\Ngc & icacls C:\Windows\ServiceProfiles\LocalService\AppData\Local\Microsoft\Ngc /T /Q /C /RESET' -Verb runAs
CLS
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name 'AllowDomainPINLogon' -Type DWord -Value 1 -Force
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\Settings\AllowSignInOptions" -Name 'value' -Type DWord -Value 1 -Force
Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Biometrics" -Recurse -Force -Confirm:$false
Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\PassportforWork" -Recurse -Force -Confirm:$false
}
$command = 'dism /Online /Disable-Feature:microsoft-hyper-v-all /NoRestart'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'dism /Online /Disable-Feature:IsolatedUserMode /NoRestart'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'dism /Online /Disable-Feature:Microsoft-Hyper-V-Hypervisor /NoRestart'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'dism /Online /Disable-Feature:Microsoft-Hyper-V-Online /NoRestart'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'dism /Online /Disable-Feature:HypervisorPlatform /NoRestart'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'mountvol X: /s'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'copy %WINDIR%\System32\SecConfig.efi X:\EFI\Microsoft\Boot\SecConfig.efi /Y'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /create {0cb3b571-2f2e-4343-a879-d86a476d7215} /d "DebugTool" /application osloader'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /set {0cb3b571-2f2e-4343-a879-d86a476d7215} path "\EFI\Microsoft\Boot\SecConfig.efi"'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /set {bootmgr} bootsequence {0cb3b571-2f2e-4343-a879-d86a476d7215}'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /set {0cb3b571-2f2e-4343-a879-d86a476d7215} loadoptions DISABLE-LSA-ISO,DISABLE-VBS'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /set {0cb3b571-2f2e-4343-a879-d86a476d7215} device partition=X:'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'mountvol X: /d'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$command = 'bcdedit /set hypervisorlaunchtype off'
Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -NoNewWindow -Wait
$DeviceGuardKey = "HKLM:\SYSTEM\ControlSet001\Control\DeviceGuard"
try
{
Remove-ItemProperty -Path $DeviceGuardKey -Name 'EnableVirtualizationBasedSecurity' -Force
} catch {}
try
{
Remove-ItemProperty -Path $DeviceGuardKey -Name 'RequirePlatformSecurityFeatures' -Force
} catch {}
$HypervisorEnforcedCodeIntegrityKey = "HKLM:\SYSTEM\ControlSet001\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity"
try
{
Set-ItemProperty -Path $HypervisorEnforcedCodeIntegrityKey -Name 'Enabled' -Type DWord -Value 0 -Force
} catch {}
CLS
Write-Output '�Э��s�Ұʨt��!'
$RebootASK = Read-Host "�z�n�ߧY���s�Ұʨt�ζ�? (Y = Yes)" -WarningAction Inquire
if ( $RebootASK -eq 'y' )
{
Restart-Computer -Force
} else {
Exit
}
}
CLS
Write-Output '�z����ܥ���Ҧ�! �Y�N�h�X PowerShell...'
Pause
Exit