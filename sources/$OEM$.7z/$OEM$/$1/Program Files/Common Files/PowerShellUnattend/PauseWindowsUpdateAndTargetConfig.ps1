# PauseWindowsUpdateAndTargetConfig PowerShell 2025-04-19
$WUPKey = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings"
$WUFoDKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
$betaWU = test-path -path $WUPKey
$betaWUPolicies = test-path -path $WUFoDKey
$BoLPrvWU = $false
if (!$betaWU)
{
New-Item -Path $WUPKey
}
if (!$betaWUPolicies)
{
New-Item -Path $WUFoDKey
}
$AskWUAddDay = Read-Host "�]�w Windows Update �Ȱ���s����Ѽ� (R = �R�����X�ë�_��s)" -WarningAction Inquire
$AskWUStop = Read-Host "�z�O�_�Q�n���� Windows Update �۰ʤU���U�@�� Windows �����\���s? (Y = �O�A�]�w�ؼЪ���;N = �_�A���i��]�m;R = �R�����X�ë�_�۰ʤU����s)" -WarningAction Inquire
$AskEWUDStop = Read-Host "�z�O�_�Q�n�ҥ� [���]�t Windows ��s���X�ʵ{��]? (Y = �O�A�ҥ�;N = �_�A���i��]�m;R = �R�����X�ë�_�۰��X�ʵ{����s)" -WarningAction Inquire
if ( $AskWUStop -eq 'y')
{
$BoLPrvWU = $true
$betaWUFoD = test-path -path $WUFoDKey
if (!$betaWUFoD)
{
New-Item -Path $WUFoDKey
}
$info = [Environment]::OSVersion.Version
$Major = $info.Major
if ([int]$info.Build -igt 21999) {
    $Major = 11
}
$OSVersion = [System.Version]::new($Major, $info.Minor, $info.Build)
$OSFoDInfo = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion") | Select-Object -Property DisplayVersion
$FoDVersion = $OSFoDInfo.DisplayVersion
try
{
Set-ItemProperty -Path $WUFoDKey -Name 'ProductVersion' -Type String -Value "Windows $Major" -Force
} catch {
New-Item -Path $WUFoDKey
New-ItemProperty -Path $WUFoDKey -Name 'ProductVersion' -PropertyType String -Value "Windows $Major" -Force
}
try
{
Set-ItemProperty -Path $WUFoDKey -Name 'TargetReleaseVersionInfo' -Type String -Value $FoDVersion -Force
} catch {
New-Item -Path $WUFoDKey
New-ItemProperty -Path $WUFoDKey -Name 'TargetReleaseVersionInfo' -PropertyType String -Value $FoDVersion -Force
}
} else {
if ( $AskWUStop -eq 'r' )
{
Remove-ItemProperty -Path $WUFoDKey -Name 'ProductVersion' -Force -Confirm:$false
Remove-ItemProperty -Path $WUFoDKey -Name 'TargetReleaseVersionInfo' -Force -Confirm:$false
}
}
if ( $AskEWUDStop -eq 'y' )
{
try
{
Set-ItemProperty -Path $WUFoDKey -Name 'ExcludeWUDriversInQualityUpdate' -Type Dword -Value 1 -Force
} catch {
New-Item -Path $WUFoDKey
New-ItemProperty -Path $WUFoDKey -Name 'ExcludeWUDriversInQualityUpdate' -PropertyType Dword -Value 1 -Force
}
try
{
Set-ItemProperty -Path $WUPKey -Name 'ExcludeWUDriversInQualityUpdate' -Type Dword -Value 1 -Force
} catch {
New-Item -Path $WUPKey
New-ItemProperty -Path $WUPKey -Name 'ExcludeWUDriversInQualityUpdate' -PropertyType Dword -Value 1 -Force
}
}
if ( $AskEWUDStop -eq 'r' )
{
Remove-ItemProperty -Path $WUFoDKey -Name 'ExcludeWUDriversInQualityUpdate' -Force -Confirm:$false
Remove-ItemProperty -Path $WUPKey -Name 'ExcludeWUDriversInQualityUpdate' -Force -Confirm:$false
}
if ( $AskWUAddDay -eq 'r' )
{
Remove-ItemProperty -Path $WUPKey -Name 'PauseFeatureUpdatesEndTime' -Force -Confirm:$false
Remove-ItemProperty -Path $WUPKey -Name 'PauseFeatureUpdatesStartTime' -Force -Confirm:$false
Remove-ItemProperty -Path $WUPKey -Name 'PauseQualityUpdatesEndTime' -Force -Confirm:$false
Remove-ItemProperty -Path $WUPKey -Name 'PauseQualityUpdatesStartTime' -Force -Confirm:$false
Remove-ItemProperty -Path $WUPKey -Name 'PauseUpdatesExpiryTime' -Force -Confirm:$false
Remove-ItemProperty -Path $WUPKey -Name 'PauseUpdatesStartTime' -Force -Confirm:$false
CLS
Write-Output '�~�� Windows Update ��s!'
if ( $BoLPrvWU )
{
Write-Output "�t�αN���d�b Windows $Major $FoDVersion!"
}
try
{
$ExcludeWUDriversInQualityUpdate = Get-ItemPropertyValue $WUFoDKey -Name 'ExcludeWUDriversInQualityUpdate'
} catch {
$ExcludeWUDriversInQualityUpdate = 0
}
Write-Output "���]�t Windows ��s���X�ʵ{��: $ExcludeWUDriversInQualityUpdate!"
} else {
try
{
if ([int]$AskWUAddDay -And [int]$AskWUAddDay -igt 0 )
{
$YearS = (Get-Date).ToString('yyyy')
$YearSReq = [int]$AskWUAddDay / 365.2
$PassYearS = [int]$YearS + [int]$YearSReq
if ( [int]$PassYearS -igt 3000 )
{
$PassYearSFixed = [int]$YearSReq - ([int]$PassYearS - 3000)
$PassYearSFixed = [int]$PassYearSFixed * 365.2
$AskWUAddDay = $PassYearSFixed
}
$StartDay = (Get-Date).AddHours(-8).ToString('yyyy-MM-ddTHH:mm:ssZ')
$PeriodDay = (Get-Date).AddHours(-8).AddDays($AskWUAddDay).ToString('yyyy-MM-ddTHH:mm:ssZ')
try
{
Set-ItemProperty -Path $WUPKey -Name 'PauseFeatureUpdatesStartTime' -Type String -Value $StartDay -Force
} catch {
New-Item -Path $WUPKey
New-ItemProperty -Path $WUPKey -Name 'PauseFeatureUpdatesStartTime' -PropertyType String -Value $StartDay -Force
}
try
{
Set-ItemProperty -Path $WUPKey -Name 'PauseQualityUpdatesStartTime' -Type String -Value $StartDay -Force
} catch {
New-Item -Path $WUPKey
New-ItemProperty -Path $WUPKey -Name 'PauseQualityUpdatesStartTime' -PropertyType String -Value $StartDay -Force
}
try
{
Set-ItemProperty -Path $WUPKey -Name 'PauseUpdatesStartTime' -Type String -Value $StartDay -Force
} catch {
New-Item -Path $WUPKey
New-ItemProperty -Path $WUPKey -Name 'PauseUpdatesStartTime' -PropertyType String -Value $StartDay -Force
}
try
{
Set-ItemProperty -Path $WUPKey -Name 'PauseFeatureUpdatesEndTime' -Type String -Value $PeriodDay -Force
} catch {
New-Item -Path $WUPKey
New-ItemProperty -Path $WUPKey -Name 'PauseFeatureUpdatesEndTime' -PropertyType String -Value $PeriodDay -Force
}
try
{
Set-ItemProperty -Path $WUPKey -Name 'PauseQualityUpdatesEndTime' -Type String -Value $PeriodDay -Force
} catch {
New-Item -Path $WUPKey
New-ItemProperty -Path $WUPKey -Name 'PauseQualityUpdatesEndTime' -PropertyType String -Value $PeriodDay -Force
}
try
{
Set-ItemProperty -Path $WUPKey -Name 'PauseUpdatesExpiryTime' -Type String -Value $PeriodDay -Force
} catch {
New-Item -Path $WUPKey
New-ItemProperty -Path $WUPKey -Name 'PauseUpdatesExpiryTime' -PropertyType String -Value $PeriodDay -Force
}
CLS
if ( $BoLPrvWU )
{
Write-Output "�t�αN���d�b Windows $Major $FoDVersion!"
}
Write-Output "�Ȱ� Windows updates ���� $PeriodDay"
try
{
$ExcludeWUDriversInQualityUpdate = Get-ItemPropertyValue $WUFoDKey -Name 'ExcludeWUDriversInQualityUpdate'
} catch {
$ExcludeWUDriversInQualityUpdate = 0
}
Write-Output "���]�t Windows ��s���X�ʵ{��: $ExcludeWUDriversInQualityUpdate!"
} else {
CLS
if ( $BoLPrvWU )
{
Write-Output "�t�αN���d�b Windows $Major $FoDVersion!"
try
{
$ExcludeWUDriversInQualityUpdate = Get-ItemPropertyValue $WUFoDKey -Name 'ExcludeWUDriversInQualityUpdate'
} catch {
$ExcludeWUDriversInQualityUpdate = 0
}
Write-Output "���]�t Windows ��s���X�ʵ{��: $ExcludeWUDriversInQualityUpdate!"
}
}
} catch {
Write-Output "OOH! ���𪺤ѼƤ��i�H��J�D�Ʀr�r��! �p�G�Q���L���]�w�п�J R"
}
}